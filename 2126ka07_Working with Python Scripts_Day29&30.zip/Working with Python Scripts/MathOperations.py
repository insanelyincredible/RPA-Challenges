def add(num1,num2):
	return num1 + num2
	
def dif(num1,num2):
	return num1 - num2